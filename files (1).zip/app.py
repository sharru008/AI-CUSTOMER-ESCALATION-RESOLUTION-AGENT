"""CYBERNEXSUS backend (Flask): REST API + serves the frontend.
Run:  pip install -r requirements.txt   then   python backend/app.py
"""
import os
from datetime import datetime, timedelta
from flask import Flask, jsonify, request, send_from_directory
import engine as E

FRONT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend")
app = Flask(__name__, static_folder=FRONT, static_url_path="")
complaints = []
STATUSES = ["Pending", "In Progress", "Resolved", "Escalated"]


def stamp(dt=None):
    return (dt or datetime.now()).strftime("%d/%m/%Y, %I:%M:%S %p")


def seed():
    complaints.clear()
    for i, s in enumerate(E.SEED):
        complaints.append({**s, "status": "Pending", "steps": [], "dec": None,
                           "created": stamp(datetime.now() - timedelta(hours=i))})
    for i in (0, 3):  # two cases already processed so the board is not empty
        r = E.analyze(complaints[i])
        complaints[i].update(steps=r["steps"], dec=r["dec"], status=r["dec"]["type"])


def find(tid):
    return next((t for t in complaints if t["id"] == tid), None)


def error(msg, code):
    return jsonify({"error": msg}), code


@app.get("/api/data")
def data():
    return jsonify(customers=E.CUSTOMERS, orders=E.ORDERS, policies=E.POLICIES)


@app.get("/api/complaints")
def list_complaints():
    return jsonify(complaints)


@app.post("/api/complaints")
def add_complaint():
    b = request.get_json(silent=True) or {}
    o = E.order(b.get("o"))
    if not E.cust(b.get("c")) or not o or o["c"] != b.get("c"):
        return error("Choose a valid customer and one of their orders", 400)
    text = str(b.get("t", "")).strip()
    if len(text) < 10:
        return error("Describe the problem in at least 10 characters", 400)
    n = {"id": f"T-{100 + len(complaints) + 1}", "c": b["c"], "o": b["o"], "t": text,
         "status": "Pending", "steps": [], "dec": None, "created": stamp()}
    complaints.insert(0, n)
    return jsonify(n), 201


@app.post("/api/complaints/<tid>/run")
def run_agents(tid):
    t = find(tid)
    if not t: return error("Complaint not found", 404)
    r = E.analyze(t)
    t.update(steps=r["steps"], dec=r["dec"], status=r["dec"]["type"])
    return jsonify(r)


@app.patch("/api/complaints/<tid>")
def update(tid):
    t = find(tid)
    if not t: return error("Complaint not found", 404)
    b = request.get_json(silent=True) or {}
    if b.get("status") in STATUSES: t["status"] = b["status"]
    if "steps" in b: t["steps"] = b["steps"]
    if "dec" in b: t["dec"] = b["dec"]
    return jsonify(t)


@app.post("/api/reset")
def reset():
    seed()
    return jsonify(ok=True)


@app.get("/")
def home():
    return send_from_directory(FRONT, "index.html")


seed()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 3000))
    print(f"CYBERNEXSUS running at http://localhost:{port}")
    app.run(host="0.0.0.0", port=port)
