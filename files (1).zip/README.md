# CYBERNEXSUS – AI Customer Escalation Resolution Agent
**Your Problem our solution**

Seven AI agents (Intent → Customer History → Order/Transaction → Policy/RAG → Root Cause → Resolution → Escalation) investigate a customer complaint and either resolve it or escalate it to a human.

## Tech
- **Backend:** Python 3 + Flask (REST API)
- **Frontend:** HTML, CSS, JavaScript (runs in the browser)

## Folder structure
```
cybernexsus-agent/
├── backend/
│   ├── app.py          Flask server and API routes
│   └── engine.py       demo data, company policies, the 7-agent logic
├── frontend/
│   ├── index.html      page
│   ├── style.css       design
│   └── app.js          screens, filters, forms (calls the API)
├── standalone/
│   └── index.html      whole site in ONE file, no setup (demo backup)
├── requirements.txt    Python packages (Flask)
├── start.bat           one-click start for Windows
├── start.sh            one-click start for Mac / Linux
└── README.md
```

## Run it
1. Install Python 3 from https://python.org (tick "Add Python to PATH").
2. Windows: double-click `start.bat`. Mac/Linux: `bash start.sh`.
   Or in a terminal inside this folder:
   ```
   pip install -r requirements.txt
   python backend/app.py
   ```
3. Open http://localhost:3000

No setup option: open `standalone/index.html` in a browser.

## API
| Method | Route | Purpose |
|---|---|---|
| GET | /api/data | customers, orders, policies |
| GET | /api/complaints | list complaints |
| POST | /api/complaints | submit a complaint `{c, o, t}` |
| POST | /api/complaints/<id>/run | run the 7 agents |
| PATCH | /api/complaints/<id> | approve / escalate / reset |
| POST | /api/reset | restore demo data |

Data is kept in memory and resets when the server restarts.

## When the agent escalates to a human
Fraud or legal threats; orders over ₹25,000; 3+ repeat tickets; amounts above auto-approve limits; confidence below 70%; angry Platinum customers.

Team: CYBERNEXSUS
