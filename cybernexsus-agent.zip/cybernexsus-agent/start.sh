#!/bin/bash
cd "$(dirname "$0")"
pip3 install -r requirements.txt
(sleep 2; open http://localhost:3000 2>/dev/null || xdg-open http://localhost:3000) &
python3 backend/app.py
