@echo off
pip install -r requirements.txt
start http://localhost:3000
python backend\app.py
pause
