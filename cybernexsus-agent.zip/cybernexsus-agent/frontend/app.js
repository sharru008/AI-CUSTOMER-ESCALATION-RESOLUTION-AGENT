// Frontend: talks to the backend through /api/... (see backend/app.py)
let CUSTOMERS=[],ORDERS=[],POLICIES={},S=[];
const cust=id=>CUSTOMERS.find(c=>c.id==id),ord=id=>ORDERS.find(o=>o.id==id),inr=n=>"₹"+n.toLocaleString("en-IN");
async function api(url,opt={}){
 try{const r=await fetch(url,{method:opt.method||"GET",headers:{"Content-Type":"application/json"},body:opt.body?JSON.stringify(opt.body):undefined});
  if(!r.ok)throw new Error((await r.json()).error||r.status);return await r.json()}
 catch(e){toast("Backend problem: "+e.message);throw e}}
function save(t){api("/api/complaints/"+t.id,{method:"PATCH",body:{status:t.status,steps:t.steps,dec:t.dec}}).catch(()=>{})}
async function load(){
 try{const d=await api("/api/data");CUSTOMERS=d.customers;ORDERS=d.orders;POLICIES=d.policies;S=await api("/api/complaints")}
 catch(e){$("detail").innerHTML='<div class="empty">Cannot reach the backend.<br>Start it with start.bat (Windows) or <b>python backend/app.py</b>, then open <b>http://localhost:3000</b></div>';return}
 $("fc").innerHTML=CUSTOMERS.map(c=>`<option value="${c.id}">${c.name} (${c.tier})</option>`).join("");fillOrders();
 $("pols").innerHTML=`<h2 style="margin:0 0 8px">Company policies the agent reads</h2>`+Object.values(POLICIES).map(p=>`<p><b>${p.id} · ${p.title}</b><br>${p.text}</p>`).join("");
 sel=sel&&S.find(t=>t.id==sel)?sel:(S[0]&&S[0].id);render();
}
let filter="All",sel=null,running=false;
const $=id=>document.getElementById(id);
function toast(m){const t=$("toast");t.textContent=m;t.classList.add("show");clearTimeout(toast.h);toast.h=setTimeout(()=>t.classList.remove("show"),2400)}
function esc(s){return String(s).replace(/[&<>"]/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]))}
function renderFilters(){
 const ST=["All","Pending","In Progress","Resolved","Escalated"];
 $("filters").innerHTML=ST.map(s=>{const n=s=="All"?S.length:S.filter(t=>t.status==s).length;return`<button class="chip ${filter==s?"on":""}" data-f="${s}">${s}<b>${n}</b></button>`}).join("");
 $("filters").querySelectorAll("button").forEach(b=>b.onclick=()=>{filter=b.dataset.f;render()});
}
function renderList(){
 const q=$("q").value.toLowerCase();
 const rows=S.filter(t=>(filter=="All"||t.status==filter)&&(`${t.id} ${cust(t.c).name} ${t.o} ${t.t}`.toLowerCase().includes(q)));
 $("list").innerHTML=rows.length?rows.map(t=>`<button class="item ${sel==t.id?"sel":""}" data-s="${t.status}" data-id="${t.id}"><div class="t"><span>${esc(cust(t.c).name)}</span><span class="badge" data-s="${t.status}">${t.status}</span></div><div class="d">${t.id} · ${esc(t.t)}</div></button>`).join(""):`<div class="empty">No complaints match this filter.</div>`;
 $("list").querySelectorAll(".item").forEach(b=>b.onclick=()=>{sel=b.dataset.id;render();if(innerWidth<820)$("detail").scrollIntoView({behavior:"smooth"})});
}
function renderDetail(){
 const t=S.find(x=>x.id==sel),d=$("detail");
 if(!t){d.innerHTML=`<div class="empty">Select a complaint on the left to see the live case.</div>`;return}
 const c=cust(t.c),o=ord(t.o),dec=t.dec;
 d.innerHTML=`<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center"><h2 style="margin:0">${t.id} · ${esc(c.name)}</h2><span><span class="badge" data-s="${t.status}">${t.status}</span> ${dec?`<span class="sev ${dec.sev}">${dec.sev} severity</span>`:""}</span></div>
 <div class="facts"><div><span>Customer</span>${esc(c.name)} (${c.tier})</div><div><span>Email</span>${c.email}</div><div><span>Order</span>${o.id} · ${o.item}</div><div><span>Amount</span>${inr(o.amt)}</div><div><span>Delivery</span>${o.status}</div><div><span>Payment</span>${o.pay}</div><div><span>Opened</span>${t.created}</div></div>
 <div class="quote">${esc(t.t)}</div>
 <h3 style="margin:14px 0 0">Agent workflow</h3>
 ${t.steps.length||t.status=="In Progress"?`<ul class="steps">${t.steps.map(s=>`<li><b>${s.a}</b>${esc(s.f)}</li>`).join("")}${t.status=="In Progress"?`<li class="wait"><b>Working…</b></li>`:""}</ul>`:`<p class="sub">The agents have not looked at this case yet.</p>`}
 ${dec?`<div class="dec ${dec.type}"><b>${dec.type=="Resolved"?"Suggested resolution":"Escalated to "+dec.team}</b><br>${esc(dec.action)}<br><small>Root cause: ${esc(dec.cause)} · Confidence ${Math.round(dec.conf*100)}%</small></div>`:""}
 <div class="row">
  <button class="btn" id="run" ${t.status!="Pending"||running?"disabled":""}>Run AI agents</button>
  ${dec?`<button class="btn green" id="ok" ${t.status=="Resolved"?"disabled":""}>Approve and resolve</button><button class="btn red" id="up" ${t.status=="Escalated"?"disabled":""}>Escalate to human</button>`:""}
  <button class="btn alt" id="rerun" ${t.status=="In Progress"||running?"disabled":""}>Reset case</button>
 </div>`;
 const g=id=>$(id);
 g("run")&&(g("run").onclick=()=>run(t.id));
 g("ok")&&(g("ok").onclick=()=>{t.status="Resolved";t.steps.push({a:"Human reviewer",f:"Approved the suggested resolution."});save(t);toast("Marked as Resolved");render()});
 g("up")&&(g("up").onclick=()=>{t.status="Escalated";t.dec={...t.dec,type:"Escalated",team:"Support lead",action:"Manually escalated by agent reviewer. Full case history attached."};save(t);toast("Escalated to a human");render()});
 g("rerun").onclick=()=>{t.status="Pending";t.steps=[];t.dec=null;save(t);render()};
}
async function run(id){
 const t=S.find(x=>x.id==id);if(!t||running)return;
 running=true;t.status="In Progress";t.steps=[];t.dec=null;render();
 try{const r=await api("/api/complaints/"+id+"/run",{method:"POST"});
  for(const s of r.steps){t.steps.push(s);render();await new Promise(z=>setTimeout(z,550))}
  t.dec=r.dec;t.status=r.dec.type;toast(`${t.id}: ${t.status}`)}
 catch(e){t.status="Pending";t.steps=[]}
 running=false;render();
}
function render(){renderFilters();renderList();renderDetail()}

$("q").oninput=renderList;
$("runAll").onclick=async()=>{const p=S.filter(t=>t.status=="Pending");if(!p.length)return toast("No pending complaints");for(const t of p){sel=t.id;await run(t.id)}};
$("reset").onclick=async()=>{await api("/api/reset",{method:"POST"});sel=null;running=false;filter="All";await load();toast("Demo data reset")};
function tab(n){["Desk","New","Pol"].forEach(k=>{$("v"+k).hidden=k!=n;$("tab"+k).classList.toggle("on",k==n)})}
$("tabDesk").onclick=()=>tab("Desk");$("tabNew").onclick=()=>tab("New");$("tabPol").onclick=()=>tab("Pol");
$("fc").innerHTML=CUSTOMERS.map(c=>`<option value="${c.id}">${c.name} (${c.tier})</option>`).join("");
function fillOrders(){$("fo").innerHTML=ORDERS.filter(o=>o.c==$("fc").value).map(o=>`<option value="${o.id}">${o.id} · ${o.item} · ${inr(o.amt)}</option>`).join("")}
$("fc").onchange=fillOrders;fillOrders();
$("submit").onclick=async()=>{
 const txt=$("ft").value.trim();
 if(txt.length<10){toast("Please describe the problem in at least 10 characters");$("ft").focus();return}
 const nt=await api("/api/complaints",{method:"POST",body:{c:$("fc").value,o:$("fo").value,t:txt}});const id=nt.id;S.unshift(nt);
 $("ft").value="";sel=id;filter="All";tab("Desk");render();toast(`Complaint ${id} submitted as Pending`);
};
$("pols").innerHTML=`<h2 style="margin:0 0 8px">Company policies the agent reads</h2>`+Object.values(POLICIES).map(p=>`<p><b>${p.id} · ${p.title}</b><br>${p.text}</p>`).join("");
load();
